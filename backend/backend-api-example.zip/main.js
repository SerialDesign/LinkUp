const express = require('express');
const bodyParser = require('body-parser');

const app = express();
let database = []; // This can be replaced with a database or local file

// Instantiate the body-parser middleware
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

// Create a new library, get ID back
app.post('/library/create', (req, res) => {
  database.push(req.body);
  res.send('Create a new library');
});

// Get a library by ID
app.get('/library/:libraryId', (req, res) => {
  res.send(`Library with id ${req.params.libraryId}`);
});

// Get all libraries by user ID
app.get('/:userId/libraries', (req, res) => {
  const filteredDatabase = database.filter(
    (library) => library.userId === req.params.userId
  );

  res.send(filteredDatabase);
});

// Start the server
app.listen(8000, () => {
  console.log('Server is listening on port 8000');
});
